const express = require('express');
const axios = require('axios');
const bodyParser = require('body-parser');
const path = require('path');
const cors = require('cors');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

let GLOBAL_ACCESS_TOKEN = "";

app.post('/authenticate', async (req, res) => {
  
});

// Middleware to check for Bearer token
const authenticateToken = async (req, res, next) => {
    try {
    await axios.get('https://qa2.sunbasedata.com/sunbase/portal/api/assignment.jsp', {
      params: { cmd: 'get_customer_list' },
      headers: { Authorization: `Bearer ${GLOBAL_ACCESS_TOKEN}` }
    });

    next();
  } catch (error) {
    res.sendStatus(401);
  }
};

app.get('/login', (req, res) => {
  res.render('login');
});



app.post('/login', async (req, res) => {
  const { username, password } = req.body;

  console.log(username, password);

  try {
    const response = await axios.post('https://qa2.sunbasedata.com/sunbase/portal/api/assignment_auth.jsp', {
      login_id: username,
      password: password
    });

    const { access_token } = response.data;
    console.log(access_token);
    
    GLOBAL_ACCESS_TOKEN = access_token;

    app.get('/delete', authenticateToken, (req, res) => {
      res.render('delete');
    });
    
    res.redirect('/delete');

  } catch (error) {
    res.status(401).json({ error: 'Authentication failed' });
  }
});

app.get('/dashboard', authenticateToken, (req, res) => {
  res.send('Dashboard Page');
});


// Create a new Customer
app.post('/create-customer', authenticateToken, async (req, res) => {
  const { first_name, last_name, street, address, city, state, email, phone } = req.body;

  if (!first_name || !last_name) {
    return res.status(400).json({ error: 'First Name or Last Name is missing' });
  }

  try {
    await axios.post('https://qa2.sunbasedata.com/sunbase/portal/api/assignment.jsp', {
      cmd: 'create',
      first_name,
      last_name,
      street,
      address,
      city,
      state,
      email,
      phone
    }, {
      headers: { Authorization: req.headers.authorization }
    });

    res.status(201).json({ message: 'Successfully Created' });
  } catch (error) {
    console.error('Error in create-customer route:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Get customer list
app.get('/get-customer-list', authenticateToken, async (req, res) => {
  try {
    const response = await axios.get('https://qa2.sunbasedata.com/sunbase/portal/api/assignment.jsp', {
      params: { cmd: 'get_customer_list' },
      headers: { Authorization: req.headers.authorization }
    });

    res.status(200).json(response.data);
  } catch (error) {
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Delete a customer
app.delete('/delete-customer/:uuid', authenticateToken, async (req, res) => {
  const { uuid } = req.params;

  try {
    await axios.post('https://qa2.sunbasedata.com/sunbase/portal/api/assignment.jsp', {
      cmd: 'delete',
      uuid
    }, {
      headers: { Authorization: req.headers.authorization }
    });

    res.status(200).json({ message: 'Successfully deleted' });
  } catch (error) {
    if (error.response && error.response.status === 400) {
      res.status(400).json({ error: 'UUID not found' });
    } else {
      res.status(500).json({ error: 'Internal Server Error' });
    }
  }
});

// Update a customer
app.post('/update-customer/:uuid', authenticateToken, async (req, res) => {
  const { uuid } = req.params;
  const { first_name, last_name, street, address, city, state, email, phone } = req.body;

  try {
    await axios.post(`https://qa2.sunbasedata.com/sunbase/portal/api/assignment.jsp?cmd=update&uuid=${uuid}`,
      {
        first_name,
        last_name,
        street,
        address,
        city,
        state,
        email,
        phone
      }, {
      headers: { Authorization: req.headers.authorization }
    });

    res.status(200).json({ message: 'Successfully Updated' });
  } catch (error) {
    if (error.response && error.response.status === 400) {
      res.status(400).json({ error: 'Body is Empty' });
    } else if (error.response && error.response.status === 500) {
      res.status(500).json({ error: 'UUID not found' });
    } else {
      res.status(500).json({ error: 'Internal Server Error' });
    }
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on PORT ${PORT}`);

});